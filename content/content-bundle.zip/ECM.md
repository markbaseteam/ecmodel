![](D:\Obsidian\ObsidianPortable\Data\Vault\image\ECM.png)
![](D:\Obsidian\ObsidianPortable\Data\Vault\image\2023-09-07-1694157772080.jpeg)